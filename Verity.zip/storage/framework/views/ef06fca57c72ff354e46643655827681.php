

<?php $__env->startSection('title', 'Job Applications - VERITY'); ?>

<?php $__env->startSection('admin-content'); ?>


<div class="filter-card fade-in">
    <div class="filter-header">
        <h4><i class="fas fa-filter"></i> Filter Applications</h4>
    </div>

    <form method="GET" action="<?php echo e(route('admin.applications.index')); ?>" class="filter-form">
        <div class="filter-grid">

            
            <div class="filter-group">
                <label><i class="fas fa-briefcase"></i> Position</label>
                <select name="position" class="filter-select">
                    <option value="">All Positions</option>
                    <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($position); ?>" <?php if(request('position') == $position): echo 'selected'; endif; ?>>
                            <?php echo e($position); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <div class="filter-group">
                <label><i class="fas fa-tag"></i> Status</label>
                <select name="status" class="filter-select">
                    <option value="">All Statuses</option>
                    <?php $__currentLoopData = ['pending','reviewed','shortlisted','rejected','hired']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status); ?>" <?php if(request('status') == $status): echo 'selected'; endif; ?>>
                            <?php echo e(ucfirst($status)); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <div class="filter-group">
                <label>&nbsp;</label>
                <div class="filter-actions">
                    <button type="submit" class="filter-btn">
                        <i class="fas fa-filter"></i> Apply
                    </button>
                    <a href="<?php echo e(route('admin.applications.index')); ?>" class="reset-btn">
                        <i class="fas fa-redo"></i> Reset
                    </a>
                </div>
            </div>

        </div>
    </form>
</div>


<div class="table-card fade-in" style="--delay:0.2s">

    <div class="table-responsive">
        <table class="applications-table">
            <thead>
                <tr>
                    <th>Applicant</th>
                    <th>Position</th>
                    <th>Current Role</th>
                    <th>Country</th>
                    <th>Status</th>
                    <th>Date Applied</th>
                    <th>Actions</th>
                </tr>
            </thead>

            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <div class="applicant-cell">
                            <div class="applicant-avatar-sm <?php echo e($app->status); ?>">
                                <?php echo e(strtoupper(substr($app->full_name, 0, 1))); ?>

                            </div>
                            <div>
                                <strong><?php echo e($app->full_name); ?></strong>
                                <span class="applicant-email"><?php echo e($app->email); ?></span>
                            </div>
                        </div>
                    </td>

                    <td><span class="position-badge"><?php echo e($app->position); ?></span></td>
                    <td><?php echo e($app->current_role); ?></td>
                    <td><?php echo e($app->country); ?></td>

                    <td>
                        <span class="status-badge status-<?php echo e($app->status); ?>">
                            <?php echo e(ucfirst($app->status)); ?>

                        </span>
                    </td>

                    <td>
                        <span><?php echo e($app->created_at->format('M d, Y')); ?></span><br>
                        <small><?php echo e($app->created_at->format('h:i A')); ?></small>
                    </td>

                    <td>
                        <div class="action-buttons">
                            <a href="<?php echo e(route('admin.applications.show', $app->id)); ?>" class="action-btn view-btn">
                                <i class="fas fa-eye"></i>
                            </a>

                            <form method="POST" action="<?php echo e(route('admin.applications.status', $app->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <select name="status" class="status-select" onchange="this.form.submit()">
                                    <?php $__currentLoopData = ['pending','reviewed','shortlisted','rejected','hired']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($status); ?>" <?php if($app->status === $status): echo 'selected'; endif; ?>>
                                            <?php echo e(ucfirst($status)); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="empty-state">
                        <p>No applications found.</p>
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    

<?php if($applications->hasPages()): ?>
    <div class="pagination-wrapper">
        <div class="compact-pagination">
            
            <?php if($applications->onFirstPage()): ?>
                <span class="page-link disabled">
                    <i class="fas fa-chevron-left"></i>
                </span>
            <?php else: ?>
                <a href="<?php echo e($applications->previousPageUrl()); ?>" class="page-link">
                    <i class="fas fa-chevron-left"></i>
                </a>
            <?php endif; ?>

            
            <?php
                $current = $applications->currentPage();
                $last = $applications->lastPage();
                $start = max(1, $current - 1);
                $end = min($last, $current + 1);
                
                if ($start > 2) {
                    $start = max(1, $current);
                    $end = min($last, $current + 2);
                }
                
                if ($end < $last - 1) {
                    $start = max(1, $current - 2);
                    $end = min($last, $current + 1);
                }
            ?>

            
            <?php if($start > 1): ?>
                <a href="<?php echo e($applications->url(1)); ?>" class="page-link">1</a>
                <?php if($start > 2): ?>
                    <span class="page-dots">...</span>
                <?php endif; ?>
            <?php endif; ?>

            
            <?php for($page = $start; $page <= $end; $page++): ?>
                <?php if($page == $current): ?>
                    <span class="page-link active"><?php echo e($page); ?></span>
                <?php else: ?>
                    <a href="<?php echo e($applications->url($page)); ?>" class="page-link"><?php echo e($page); ?></a>
                <?php endif; ?>
            <?php endfor; ?>

            
            <?php if($end < $last): ?>
                <?php if($end < $last - 1): ?>
                    <span class="page-dots">...</span>
                <?php endif; ?>
                <a href="<?php echo e($applications->url($last)); ?>" class="page-link"><?php echo e($last); ?></a>
            <?php endif; ?>

            
            <?php if($applications->hasMorePages()): ?>
                <a href="<?php echo e($applications->nextPageUrl()); ?>" class="page-link">
                    <i class="fas fa-chevron-right"></i>
                </a>
            <?php else: ?>
                <span class="page-link disabled">
                    <i class="fas fa-chevron-right"></i>
                </span>
            <?php endif; ?>
        </div>
        
        <div class="pagination-info">
            Showing <strong><?php echo e($applications->firstItem() ?? 0); ?>-<?php echo e($applications->lastItem() ?? 0); ?></strong>
            of <strong><?php echo e($applications->total()); ?></strong> applications
        </div>
    </div>
<?php endif; ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\Laravel Projects\Verity\resources\views/admin/applications/index.blade.php ENDPATH**/ ?>