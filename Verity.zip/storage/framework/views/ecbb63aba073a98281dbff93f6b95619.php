

<?php $__env->startSection('noHeader'); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('noFooter'); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Admin Login - VERITY'); ?>

<?php $__env->startSection('content'); ?>
<div class="login-wrapper">

    <div class="login-card">

        
        <div class="login-header">
            <img src="<?php echo e(asset('assets/Logo Final-01.png')); ?>"
                 alt="VERITY Logo"
                 class="login-logo">

            <h2>Admin Login</h2>
            <p>Sign in to access the dashboard</p>
        </div>

        
        <?php if(session('error')): ?>
            <div class="login-error">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        
        <form method="POST"
              action="<?php echo e(route('login.submit')); ?>"
              class="login-form">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label>Email</label>
                <input type="email"
                       name="email"
                       required
                       autofocus
                       placeholder="admin@verity.com">
            </div>

            <div class="form-group">
                <label>Password</label>
                <input type="password"
                       name="password"
                       required
                       placeholder="••••••••">
            </div>

            <button type="submit" class="login-btn">
                Login
            </button>
        </form>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\Laravel Projects\Verity\resources\views/auth/login.blade.php ENDPATH**/ ?>