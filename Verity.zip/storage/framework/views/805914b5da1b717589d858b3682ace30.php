

<?php $__env->startSection('content'); ?>

<section class="case-wrapper">
    <div class="container">

        <!-- Breadcrumb -->
        <div class="case-breadcrumb">
            <a href="<?php echo e(route('portfolio.index')); ?>">Portfolio</a>
            <span>/</span>
            <span class="current"><?php echo e($project->title); ?></span>
        </div>

        <!-- Main Layout -->
        <div class="case-layout">

            <!-- LEFT : Overview -->
            <div class="case-content">
                <h2>Project Overview</h2>

                <p><?php echo $project->description; ?></p>

                <h3>Challenges</h3>
                <p>
                    The project required scalable backend architecture,
                    optimized performance, and seamless user experience
                    across multiple devices and user roles.
                </p>

                <h3>Solution</h3>
                <p>
                    We designed a modular Laravel-based system,
                    implemented efficient database structure,
                    and built a clean responsive interface
                    aligned with modern UI/UX standards.
                </p>
            </div>

            <!-- RIGHT : Image -->
            <div class="case-image">
                <img src="<?php echo e(asset($project->thumbnail)); ?>" alt="<?php echo e($project->title); ?>">

                <!-- Bottom Meta Section -->
        <div class="case-bottom">

            <div class="bottom-header">
                <span class="project-category"><?php echo e($project->category); ?></span>
                <h3><?php echo e($project->title); ?></h3>
                <p class="short-desc"><?php echo e($project->short_description); ?></p>
            </div>

            <div class="bottom-grid">

                <div>
                    <small>Client</small>
                    <strong><?php echo e($project->client ?? 'Confidential'); ?></strong>
                </div>

                <div>
                    <small>Industry</small>
                    <strong><?php echo e($project->industry ?? 'Technology'); ?></strong>
                </div>

                <div>
                    <small>Year</small>
                    <strong><?php echo e($project->created_at->format('Y')); ?></strong>
                </div>

            </div>

            <?php if($project->technologies): ?>
                <div class="tech-tags">
                    <?php $__currentLoopData = explode(',', $project->technologies); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span><?php echo e(trim($tech)); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

        </div>
            </div>
            
        </div>

        

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/css/portfolio-show.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('assets/js/portfolio-show.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\Laravel Projects\Verity\resources\views/pages/portfolio/show.blade.php ENDPATH**/ ?>