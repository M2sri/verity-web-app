

<?php $__env->startSection('title', 'Admin Dashboard - VERITY'); ?>
<?php $__env->startSection('page-title', 'Dashboard Overview'); ?>

<?php $__env->startSection('admin-content'); ?>


<div class="dashboard-stats fade-in" style="--delay: 0.1s">

    <?php
        $total = \App\Models\JobApplication::count();
        $pending = \App\Models\JobApplication::where('status','pending')->count();
        $shortlisted = \App\Models\JobApplication::where('status','shortlisted')->count();
        $hired = \App\Models\JobApplication::where('status','hired')->count();
        $rate = $total > 0 ? round(($hired / $total) * 100) : 0;
    ?>

    <div class="stat-card">
        <div class="stat-icon"><i class="fas fa-layer-group"></i></div>
        <h3><?php echo e($total); ?></h3>
        <p>Total Applications</p>
    </div>

    <div class="stat-card">
        <div class="stat-icon"><i class="fas fa-clock"></i></div>
        <h3><?php echo e($pending); ?></h3>
        <p>Pending Review</p>
    </div>

    <div class="stat-card">
        <div class="stat-icon"><i class="fas fa-star"></i></div>
        <h3><?php echo e($shortlisted); ?></h3>
        <p>Shortlisted</p>
    </div>

    <div class="stat-card">
        <div class="stat-icon"><i class="fas fa-check-circle"></i></div>
        <h3><?php echo e($hired); ?></h3>
        <p>Hired (<?php echo e($rate); ?>%)</p>
    </div>
</div>


<div class="dashboard-content fade-in" style="animation-delay: 0.2s">
    <div class="content-grid">

        <div class="content-card">
            <div class="card-header">
                <h3>Recent Applications</h3>
                <a href="<?php echo e(route('admin.applications.index')); ?>" class="view-all">
                    View All <i class="fas fa-arrow-right"></i>
                </a>
            </div>

            <div class="applications-list">
                <?php $__empty_1 = true; $__currentLoopData = $recentApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="application-item">
                        <div class="applicant-avatar <?php echo e($application->status); ?>">
                            <?php echo e(strtoupper(substr($application->full_name, 0, 1))); ?>

                        </div>

                        <div class="applicant-info">
                            <strong><?php echo e($application->full_name); ?></strong>
                            <span><?php echo e($application->position); ?></span>
                        </div>

                        <span class="status-badge status-<?php echo e($application->status); ?>">
                            <?php echo e(ucfirst($application->status)); ?>

                        </span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="empty-state">No applications found.</p>
                <?php endif; ?>
            </div>
        </div>

        
        <div class="content-card">
            <h3>Quick Actions</h3>

            <a href="<?php echo e(route('admin.applications.index')); ?>" class="quick-action">
                <i class="fas fa-users"></i>
                View Applications
            </a>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\Laravel Projects\Verity\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>