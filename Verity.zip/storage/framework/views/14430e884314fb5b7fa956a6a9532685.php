

<?php $__env->startSection('noHeader'); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('noFooter'); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'Application Details'); ?>

<?php $__env->startSection('content'); ?>

<style>

</style>

<div class="container">
<div class="application-view">

    
    <div class="app-header">
        <div class="app-title">
            <h1><?php echo e($application->full_name); ?></h1>
            <p class="position"><?php echo e($application->position); ?></p>
        </div>

        <span class="status-badge status-<?php echo e($application->status); ?>">
            <?php echo e(ucfirst($application->status)); ?>

        </span>
    </div>

    
    <div class="card">
        <h3>👤 Personal Information</h3>
        <div class="info-grid">
            <div class="info-item"><span>Email</span><strong><?php echo e($application->email); ?></strong></div>
            <div class="info-item"><span>Phone</span><strong><?php echo e($application->phone); ?></strong></div>
            <div class="info-item"><span>WhatsApp</span><strong><?php echo e($application->whatsapp ?? '—'); ?></strong></div>
            <div class="info-item"><span>Location</span><strong><?php echo e($application->country); ?></strong></div>
            <div class="info-item"><span>LinkedIn</span>
                <?php echo $application->linkedin ? '<a href="'.$application->linkedin.'" target="_blank">View Profile</a>' : '<strong>—</strong>'; ?>

            </div>
            <div class="info-item"><span>Portfolio</span>
                <?php echo $application->portfolio ? '<a href="'.$application->portfolio.'" target="_blank">View</a>' : '<strong>—</strong>'; ?>

            </div>
        </div>
    </div>

    
    <div class="card">
        <h3>💼 Employment Details</h3>
        <div class="info-grid">
            <div class="info-item"><span>Employment Type</span><strong><?php echo e($application->employment_type); ?></strong></div>
            <div class="info-item"><span>Availability</span><strong><?php echo e($application->availability); ?></strong></div>
            <div class="info-item"><span>Experience</span><strong><?php echo e($application->experience); ?></strong></div>
            <div class="info-item"><span>Current Role</span><strong><?php echo e($application->current_role); ?></strong></div>
            <div class="info-item"><span>Company</span><strong><?php echo e($application->company_name ?? '—'); ?></strong></div>
        </div>
    </div>

    
    <div class="card">
        <h3>📊 Responsibilities & Achievements</h3>
        <div class="long-text"><?php echo e($application->responsibilities); ?></div>
    </div>

    
    <div class="card">
        <h3>🎓 Education</h3>
        <div class="info-grid">
            <div class="info-item"><span>Qualification</span><strong><?php echo e($application->qualification); ?></strong></div>
            <div class="info-item"><span>Field</span><strong><?php echo e($application->field_of_study); ?></strong></div>
            <div class="info-item"><span>Institution</span><strong><?php echo e($application->institution); ?></strong></div>
            <div class="info-item"><span>Year</span><strong><?php echo e($application->graduation_year); ?></strong></div>
        </div>
    </div>

    
    <div class="card">
        <h3>🌟 Motivation</h3>
        <p class="section-label">Why VERITY</p>
        <div class="long-text"><?php echo e($application->why_verity); ?></div>
        <p class="section-label">Value Add</p>
        <div class="long-text"><?php echo e($application->value_add); ?></div>
    </div>

    
    <div class="card">
        <h3>📄 Resume</h3>
        <a href="<?php echo e(asset('storage/'.$application->resume)); ?>" target="_blank" class="btn-primary">
            <i class="fas fa-file-pdf"></i> View Resume
        </a>
    </div>

  

        <a href="<?php echo e(route('admin.applications.index')); ?>" class="btn-outline">
            ← Back to Applications
        </a>
    </div>

</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH X:\Laravel Projects\Verity\resources\views/admin/applications/show.blade.php ENDPATH**/ ?>